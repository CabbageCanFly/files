'use strict';
// Receive Codex's JSON event as an argv argument, resolve its *own* session
// metadata, and forward both the correct project label and original event JSON
// to the existing Code-Notify PowerShell script via stdin.
const fs = require('fs');
const path = require('path');
const os = require('os');
const cp = require('child_process');

const home = os.homedir();
const configDir = path.join(home, '.config', 'code-notify');
const logFile = path.join(configDir, 'codex-bridge.log');
const scriptPath = path.join(home, '.claude', 'notifications', 'notify.ps1');
const sessionsDir = path.join(process.env.CODEX_HOME || path.join(home, '.codex'), 'sessions');

function log(message) {
  try {
    fs.mkdirSync(configDir, { recursive: true });
    fs.appendFileSync(logFile, `${new Date().toISOString()} ${message}\n`, 'utf8');
  } catch (_) { /* Never interrupt Codex on logging errors. */ }
}

function labelFromCwd(cwd) {
  if (typeof cwd !== 'string') return '';
  const normalized = cwd.trim().replace(/[\\/]+$/, '');
  return normalized.split(/[\\/]/).pop() || '';
}

// Only read the FIRST LINE of the matching rollout, which contains session_meta.
// Never read conversation messages or send them anywhere.
function getSessionCwd(threadId) {
  if (typeof threadId !== 'string' || !/^[a-f0-9-]{32,40}$/i.test(threadId)) return '';
  if (!fs.existsSync(sessionsDir)) return '';
  const target = threadId.toLowerCase() + '.jsonl';
  const stack = [sessionsDir];
  let visited = 0;
  while (stack.length && visited < 20000) {
    const dir = stack.pop();
    let items;
    try { items = fs.readdirSync(dir, { withFileTypes: true }); } catch (_) { continue; }
    for (const item of items) {
      visited++;
      const full = path.join(dir, item.name);
      if (item.isDirectory()) {
        stack.push(full);
      } else if (item.isFile() && item.name.toLowerCase().startsWith('rollout-') && item.name.toLowerCase().endsWith(target)) {
        let fd;
        try {
          fd = fs.openSync(full, 'r');
          const buf = Buffer.alloc(32768);
          const count = fs.readSync(fd, buf, 0, buf.length, 0);
          const line = buf.toString('utf8', 0, count).split(/\r?\n/, 1)[0].replace(/^\uFEFF/, '');
          const record = JSON.parse(line);
          const meta = record && record.payload;
          if (record.type === 'session_meta' &&
              meta && typeof meta.id === 'string' &&
              meta.id.toLowerCase() === threadId.toLowerCase() &&
              typeof meta.cwd === 'string') {
            return meta.cwd;
          }
        } catch (_) { /* Try another rollout. */ }
        finally { if (fd !== undefined) try { fs.closeSync(fd); } catch (_) {} }
      }
    }
  }
  return '';
}

if (process.argv[2] === '--test') {
  console.log('Bridge loads successfully. No Discord message sent.');
  process.exit(0);
}

let event;
const raw = process.argv[2] || '';
try { event = JSON.parse(raw); } catch (_) { event = null; }

let project = event ? labelFromCwd(event.cwd) : '';
let resolvedFrom = 'event-cwd';
if (!project || project.toLowerCase() === 'workdir') {
  const saved = getSessionCwd(event && event['thread-id']);
  const savedName = labelFromCwd(saved);
  if (savedName && savedName.toLowerCase() !== 'workdir') {
    project = savedName;
    resolvedFrom = 'session-meta';
  } else {
    resolvedFrom = 'fallback';
  }
}
if (!project) project = 'workdir';

// Pass the whole validated JSON through STDIN, not the command line, so
// PowerShell can parse thread-id/turn-id for the existing 4s dedupe patch.
const forwarded = event ? JSON.stringify(event) : raw;
log(`validJson=${!!event} project=${JSON.stringify(project)} source=${resolvedFrom}`);
if (!fs.existsSync(scriptPath)) {
  log('ERROR: Code-Notify notify.ps1 not found');
  process.exit(1);
}

const result = cp.spawnSync('powershell.exe', [
  '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', scriptPath,
  'stop', 'codex', project
], { input: forwarded, encoding: 'utf8', windowsHide: true, timeout: 30000, maxBuffer: 1024 * 1024 });
if (result.error || result.status !== 0) {
  log(`ERROR: Code-Notify exited status=${result.status} reason=${result.error ? result.error.code : 'process-error'}`);
  process.exit(1);
}